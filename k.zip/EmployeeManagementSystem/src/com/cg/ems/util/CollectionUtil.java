package com.cg.ems.util;

import java.time.LocalDate;
import java.time.Month;
import java.util.HashSet;

import com.cg.ems.dto.Employee;

public class CollectionUtil {
	private static HashSet<Employee> empSet = new HashSet<Employee>();

	 static
	 {
		 empSet.add(new Employee(1121,"Kanchan",5555.0F,LocalDate.of(2014, Month.MARCH, 04)));
		 empSet.add(new Employee(1122,"Karamjeet",4444.0F,LocalDate.of(2014, Month.SEPTEMBER, 84)));
		 empSet.add(new Employee(1123,"diksha",3333.0F,LocalDate.of(2018, Month.MARCH, 25)));
		 empSet.add(new Employee(1124,"harshita",2222.0F,LocalDate.of(2017, Month.DECEMBER, 34)));
		 empSet.add(new Employee(1125,"Archana",1111.0F,LocalDate.of(2016, Month.OCTOBER, 54)));
		 empSet.add(new Employee(1126,"gayatri",6666.0F,LocalDate.of(2018, Month.JANUARY, 24)));

	}
	 public static void addEmp(Employee emp){
		 empSet.add(emp);
		
	 }
	 public static HashSet<Employee> getAllEmp(){
		 return empSet;
	 }
	 public static HashSet<Employee> getEmpByName(){
		 return empSet;
	 }

}
