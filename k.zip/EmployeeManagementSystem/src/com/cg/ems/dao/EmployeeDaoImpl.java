package com.cg.ems.dao;

import java.util.HashSet;

import java.util.Iterator;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.CollectionUtil;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public int addEmployee(Employee ee) throws EmployeeException {
		CollectionUtil.addEmp(ee);
		return ee.getEmpId();
	}

	@Override
	public HashSet<Employee> fetchAllEmp() {
		
		return CollectionUtil.getAllEmp();
	}

	@Override
	public Employee getEmpById(int empId) {
		HashSet<Employee> empSet = CollectionUtil.getAllEmp();
		Iterator<Employee> it = empSet.iterator();
		while(it.hasNext())
		{
			Employee ee = it.next();
			if(ee.getEmpId()==empId)
			{
				return ee;
			}	
			
		}
		return null;
	}

	@Override
	public HashSet<Employee> searchEmpByName(String name) {
		HashSet<Employee> empSet = CollectionUtil.getAllEmp();
		Iterator<Employee> it = empSet.iterator();
		HashSet<Employee> hs = new HashSet<Employee>();
		while(it.hasNext())
		{
			Employee ee = it.next();
			if(ee.getEmpName().equals(name))
			{
				hs.add(ee);
			}	
			
		}
		return hs;
	}

	@Override
	public int deleteEmp(int empId) {
		HashSet<Employee> empSet = CollectionUtil.getAllEmp();
		Iterator<Employee> it = empSet.iterator();
		while(it.hasNext())
		{
			Employee ee = it.next();
			if(ee.getEmpId()==empId)
			{
				empSet.remove(ee);
				return 1;
			}	
			
		}
		return 0;
	}

	@Override
	public Employee updateEmp(int empId, String newName, float newSal) {
		// TODO Auto-generated method stub
		return null;
	}

}
